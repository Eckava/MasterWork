﻿async function loadStatus() {
    try {
        const res = await fetch('/api/dashboard/status');
        const data = await res.json();

        console.log("API Data:", data);  // Add this for debugging

        const scripts = data.scripts || [];
        const zoho = data.zoho || {};

        const tbody = document.querySelector('#statusTable tbody');
        tbody.innerHTML = ''; // clear

        // First row: Zoho People status
        const zohoTr = document.createElement('tr');

        // Column: Script Name
        const zohoName = document.createElement('td');
        zohoName.textContent = 'Zoho People Sync';
        zohoTr.appendChild(zohoName);

        // Column: Last Run Timestamp
        const zohoLastRun = document.createElement('td');
        const zohoDt = new Date(zoho.lastSync);
        zohoLastRun.textContent = isNaN(zohoDt)
            ? 'Never'
            : `${zohoDt.getFullYear()}-${String(zohoDt.getMonth() + 1).padStart(2, '0')}-${String(zohoDt.getDate()).padStart(2, '0')} `
            + `${String(zohoDt.getHours()).padStart(2, '0')}:${String(zohoDt.getMinutes()).padStart(2, '0')}:${String(zohoDt.getSeconds()).padStart(2, '0')}`;

        zohoTr.appendChild(zohoLastRun);

        // Column: Status with class based on value
        const zohoStatus = document.createElement('td');
        const normalizedStatus = (zoho.lastStatus || '').trim().toLowerCase();
        zohoStatus.textContent = zoho.lastStatus || 'Unknown';
        zohoStatus.className = (normalizedStatus === 'success' || normalizedStatus === 'completed')
            ? 'status-success'
            : 'status-error';
        zohoTr.appendChild(zohoStatus);

        // Column: Log (none for Zoho sync)
        const emptyLog = document.createElement('td');
        emptyLog.textContent = '-';
        zohoTr.appendChild(emptyLog);

        // Append to table body
        tbody.appendChild(zohoTr);


        // Rows for each script
        scripts.forEach(item => {
            const tr = document.createElement('tr');

            // Name
            const nameTd = document.createElement('td');
            let displayName = item.name;
            if (displayName === 'ADUsersSync') displayName = 'Ad User Sync';
            if (displayName === 'CountryReset') displayName = 'Check Suspicious Logins';
            nameTd.textContent = displayName;
            tr.appendChild(nameTd);

            // Last Run
            const runTd = document.createElement('td');
            const dt = new Date(item.lastRun);
            runTd.textContent = isNaN(dt)
                ? 'Never'
                : `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')} `
                + `${String(dt.getHours()).padStart(2, '0')}:${String(dt.getMinutes()).padStart(2, '0')}:${String(dt.getSeconds()).padStart(2, '0')}`;

            tr.appendChild(runTd);


            // Status
            const statusTd = document.createElement('td');
            statusTd.textContent = item.lastStatus || 'Unknown';
            statusTd.className = item.lastStatus?.toLowerCase() === 'success'
                ? 'status-success'
                : 'status-error';
            tr.appendChild(statusTd);

            // View Log
            const logTd = document.createElement('td');
            const logLink = document.createElement('a');
            logLink.textContent = 'View Log';
            logLink.href = `/api/dashboard/log/${encodeURIComponent(item.name)}`;
            logLink.target = '_blank';
            logTd.appendChild(logLink);
            tr.appendChild(logTd);

            tbody.appendChild(tr);
        });

    } catch (err) {
        console.error('Failed to load status:', err);
    }
}

window.addEventListener('load', loadStatus);
