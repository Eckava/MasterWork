﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using AdSyncService.Services; // ScriptStatusService & ZohoService

namespace AdSyncService
{
    public static class Program
    {
        public static async Task Main(string[] args)
        {
            var builder = Host
                .CreateDefaultBuilder(args)
#if !DEBUG
                .UseWindowsService()   // run as a Windows Service when not debugging
#endif
                .ConfigureLogging((ctx, log) =>
                {
                    log.ClearProviders();
                    log.AddConsole();
                    log.AddEventLog();   // Windows‐only event log
                })
                .ConfigureServices((ctx, services) =>
                {
                    // register the in‐memory status store & your Worker
                    services.AddSingleton<ScriptStatusService>();
                    services.AddSingleton<ZohoService>();   // ✅ Add ZohoService registration
                    services.AddHostedService<Worker>();
                })
                .ConfigureWebHostDefaults(web =>
                {
                    web.ConfigureServices(services =>
                    {
                        services.AddControllers();
                    });

                    web.Configure(app =>
                    {
                        // serve wwwroot/index.html on "/"
                        app.UseDefaultFiles();
                        // serve all static files from wwwroot
                        app.UseStaticFiles();

                        app.UseRouting();
                        app.UseEndpoints(endpoints =>
                        {
                            // API controllers (e.g. /api/status, /api/log/{script})
                            endpoints.MapControllers();
                        });
                    });
                });

            await builder.Build().RunAsync();
        }
    }
}
