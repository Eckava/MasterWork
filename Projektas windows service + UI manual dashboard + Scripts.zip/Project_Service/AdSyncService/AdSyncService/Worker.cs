﻿using System;
using System.IO;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using SysTimer = System.Timers.Timer;
using AdSyncService.Services;

namespace AdSyncService
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private readonly ScriptStatusService _statusSvc;
        private readonly ZohoService _zohoService;   // ⬅ ADD THIS

        // Your real scripts here:
        private readonly string _countryResetScript =
            @"C:\Projects\HrAdSyncDashboard\Scripts\checkCountrystatusreset.ps1";
        private readonly string _adUsersScript =
            @"C:\Projects\HrAdSyncDashboard\Scripts\Create-ADUsers.ps1";

        private SysTimer? _t10m, _t3h, _zohoTimer;   // ⬅ ADD _zohoTimer

        // Updated constructor to accept ZohoService
        public Worker(ILogger<Worker> logger, ScriptStatusService statusSvc, ZohoService zohoService)
        {
            _logger = logger;
            _statusSvc = statusSvc;
            _zohoService = zohoService;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            // 1️⃣ Run both scripts once at startup
            RunAndTrack(_countryResetScript, "CountryReset");
            RunAndTrack(_adUsersScript, "AdUsersSync");

            // ✅ Run Zoho sync immediately once
            try
            {
                _logger.LogInformation("Starting initial Zoho sync...");
                await _zohoService.FetchEmployeesAndSaveJson();
                _logger.LogInformation("Initial Zoho sync completed.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Initial Zoho sync failed.");
            }

            // 2️⃣ Schedule CountryReset every 10 minutes
            _t10m = new SysTimer(TimeSpan.FromMinutes(10).TotalMilliseconds)
            {
                AutoReset = true
            };
            _t10m.Elapsed += (_, __) => RunAndTrack(_countryResetScript, "CountryReset");
            _statusSvc.RegisterTimer("CountryReset", _t10m);
            _t10m.Start();

            // 3️⃣ Schedule AdUsersSync every 10 minutes
            _t3h = new SysTimer(TimeSpan.FromMinutes(10).TotalMilliseconds)
            {
                AutoReset = true
            };
            _t3h.Elapsed += (_, __) => RunAndTrack(_adUsersScript, "AdUsersSync");
            _statusSvc.RegisterTimer("AdUsersSync", _t3h);
            _t3h.Start();

            // 4️⃣ Schedule Zoho sync every 9 minutes
            _zohoTimer = new SysTimer(TimeSpan.FromMinutes(9).TotalMilliseconds)
            {
                AutoReset = true
            };
            _zohoTimer.Elapsed += async (_, __) =>
            {
                try
                {
                    _logger.LogInformation("Scheduled Zoho sync starting...");
                    await _zohoService.FetchEmployeesAndSaveJson();
                    _logger.LogInformation("Scheduled Zoho sync completed.");
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Scheduled Zoho sync failed.");
                }
            };
            _zohoTimer.Start();

            await Task.CompletedTask;
        }


        private void RunAndTrack(string scriptPath, string name)
        {
            _logger.LogInformation("Starting {name} at {time}", name, DateTimeOffset.Now);

            var info = new ScriptInfo
            {
                Name = name,
                LastRun = DateTimeOffset.Now
            };

            string stdout = "", stderr = "";

            try
            {
                var psi = new ProcessStartInfo("powershell.exe",
                    $"-NoProfile -ExecutionPolicy Bypass -File \"{scriptPath}\"")
                {
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };

                using var proc = Process.Start(psi)
                    ?? throw new InvalidOperationException("Could not start PowerShell");

                stdout = proc.StandardOutput.ReadToEnd();
                stderr = proc.StandardError.ReadToEnd();
                proc.WaitForExit();

                info.LastStatus = proc.ExitCode == 0 ? "Success" : "Error";

                if (!string.IsNullOrWhiteSpace(stdout))
                    _logger.LogInformation(stdout.Trim());
                if (!string.IsNullOrWhiteSpace(stderr))
                    _logger.LogError(stderr.Trim());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error running {name}", name);
                info.LastStatus = "Exception";
                stderr = ex.ToString();
            }

            // ✅ Write log file
            var logDir = Path.Combine(AppContext.BaseDirectory, "Data");
            Directory.CreateDirectory(logDir);

            var timestamp = DateTimeOffset.Now.ToString("yyyy-MM-dd_HH-mm-ss");
            var logFile = Path.Combine(logDir, $"{name}_{timestamp}.log");
            File.WriteAllText(logFile,
                $"--- STDOUT ---{Environment.NewLine}{stdout}{Environment.NewLine}" +
                $"--- STDERR ---{Environment.NewLine}{stderr}");

            info.LastLogPath = logFile;

            _statusSvc.Update(info);
        }

        public override Task StopAsync(CancellationToken cancellationToken)
        {
            _t10m?.Stop();
            _t10m?.Dispose();
            _t3h?.Stop();
            _t3h?.Dispose();
            _zohoTimer?.Stop();    // ⬅ Stop Zoho timer too
            _zohoTimer?.Dispose();
            return base.StopAsync(cancellationToken);
        }
    }
}
