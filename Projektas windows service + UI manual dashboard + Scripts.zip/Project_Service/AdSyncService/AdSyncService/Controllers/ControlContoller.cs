﻿using Microsoft.AspNetCore.Mvc;
using AdSyncService.Services;

namespace AdSyncService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ControlController : ControllerBase
    {
        private readonly ScriptStatusService _svc;
        public ControlController(ScriptStatusService svc)
            => _svc = svc;

        // POST /api/control/{name}/start
        [HttpPost("{name}/start")]
        public IActionResult Start(string name)
        {
            return _svc.Start(name)
                ? Ok()
                : NotFound(new { message = $"No timer for '{name}'" });
        }

        // POST /api/control/{name}/stop
        [HttpPost("{name}/stop")]
        public IActionResult Stop(string name)
        {
            return _svc.Stop(name)
                ? Ok()
                : NotFound(new { message = $"No timer for '{name}'" });
        }
    }
}
