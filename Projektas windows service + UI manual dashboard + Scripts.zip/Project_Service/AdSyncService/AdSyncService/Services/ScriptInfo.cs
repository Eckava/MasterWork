﻿using System;

namespace AdSyncService.Services
{
    public class ScriptInfo
    {
        public string Name { get; set; } = default!;
        public DateTimeOffset LastRun { get; set; }
        public string LastStatus { get; set; } = default!;
        public string? LastOutput { get; set; }
        public string? LastError { get; set; }
        public string LastLogPath { get; set; } = default!;

        // is the timer currently enabled/running?
        public bool IsEnabled { get; set; }
    }
}
