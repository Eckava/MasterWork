﻿using System.Text.Json;
using System.Net.Http.Headers;
using AdSyncService.Models;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Linq;
using System.Threading.Tasks;
using System;

namespace AdSyncService.Services;

public class ZohoService
{
    private readonly ILogger<ZohoService> _logger;

    // Reuse same credentials from WPF
    private const string clientId = "1000.TJC7X3DH25BIEO17A5WUHF7EWWEVFC";
    private const string clientSecret = "a45c18e8c747742554aa5190932300343e0cff94ad";

    private readonly string _tokenFile;
    private readonly string _outputJson;

    // 👇 New properties so DashboardController can report sync status
    public DateTime? LastSyncTime { get; private set; }
    public string LastStatus { get; private set; } = "Never synced";

    public ZohoService(ILogger<ZohoService> logger)
    {
        _logger = logger;

        _tokenFile = Path.Combine(AppContext.BaseDirectory, "Data", "zoho_token.json");
        _outputJson = Path.Combine(AppContext.BaseDirectory, "Data", "LatestZoho.json");
    }

    public async Task FetchEmployeesAndSaveJson()
    {
        _logger.LogInformation("Zoho: Starting employee fetch...");

        try
        {
            var token = await GetValidToken();

            using var client = new HttpClient();
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token.access_token);

            var domain = string.IsNullOrWhiteSpace(token.api_domain)
                ? "https://people.zoho.eu"
                : token.api_domain.Replace("www.zohoapis.eu", "people.zoho.eu");

            var empUrl = $"{domain}/people/api/forms/P_EmployeeView/records?includeChild=true";
            var response = await client.GetAsync(empUrl);
            var raw = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception($"Zoho API error {(int)response.StatusCode}: {raw}");

            var emps = JsonSerializer.Deserialize<List<Dictionary<string, object>>>(raw)!;

            var list = new List<EmployeeExport>();
            int id = 1;

            foreach (var emp in emps)
            {
                var zohoStatus = emp.GetValueOrDefault("Employee Status")?.ToString() ?? "";
                var email = emp.GetValueOrDefault("Email address")?.ToString() ?? "";
                var dept = emp.GetValueOrDefault("Department")?.ToString() ?? "";
                var role = emp.GetValueOrDefault("Zoho Role")?.ToString() ?? "";
                var key = emp.GetValueOrDefault("Employee ID")?.ToString() ?? "";

                string startRaw = "";
                string durRaw = "";
                string purpose = "";
                string endRaw = "";

                if (emp.TryGetValue("Travel Initiate", out var childObj)
                 && childObj is JsonElement je
                 && je.ValueKind == JsonValueKind.Array)
                {
                    var travelEntries = JsonSerializer.Deserialize<List<Dictionary<string, object>>>(je.GetRawText())!;
                    var latest = travelEntries.FirstOrDefault(); // ⬅ here FirstOrDefault will now work (don't forget using System.Linq!)
                    if (latest != null)
                    {
                        startRaw = latest.GetValueOrDefault("ExpectedDateOfDeparture")?.ToString() ?? "";
                        durRaw = latest.GetValueOrDefault("Expectedduration")?.ToString() ?? "";
                        purpose = latest.GetValueOrDefault("PurposeOfVisit")?.ToString() ?? "";
                    }
                }

                if (DateTime.TryParse(startRaw, out var startDt)
                 && int.TryParse(durRaw, out var days))
                {
                    endRaw = startDt.AddDays(days).ToString("yyyy-MM-dd");
                }

                list.Add(new EmployeeExport
                {
                    ID = (id++).ToString(),
                    FirstName = emp.GetValueOrDefault("First Name")?.ToString() ?? "",
                    LastName = emp.GetValueOrDefault("Last Name")?.ToString() ?? "",
                    FullName = $"{emp.GetValueOrDefault("First Name")} {emp.GetValueOrDefault("Last Name")}".Trim(),
                    Email = email,
                    EmployeeID = key,
                    Status = zohoStatus.Equals("Active", StringComparison.OrdinalIgnoreCase) ? "Active" : "Disabled",
                    Department = dept,
                    ZohoRole = role,
                    StartDate = emp.GetValueOrDefault("Date of Joining")?.ToString() ?? "",
                    LeaveDate = emp.GetValueOrDefault("Date of Exit")?.ToString() ?? "",
                    TravelStartDate = startRaw,
                    TravelEndDate = endRaw,
                    VacationStatus = purpose.Equals("Vacation", StringComparison.OrdinalIgnoreCase) ? "1" : "0"
                });
            }

            var json = JsonSerializer.Serialize(list, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(_outputJson, json);

            _logger.LogInformation("Zoho: Employee data saved to " + _outputJson);

            // ✅ Success tracking
            LastSyncTime = DateTime.Now;
            LastStatus = "Success";
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Zoho: Sync failed.");
            LastSyncTime = DateTime.Now;
            LastStatus = $"Error: {ex.Message}";
            throw;
        }
    }

    private async Task<ZohoToken> GetValidToken()
    {
        if (!File.Exists(_tokenFile))
            throw new Exception("zoho_token.json not found.");

        var txt = await File.ReadAllTextAsync(_tokenFile);
        var stored = JsonSerializer.Deserialize<ZohoToken>(txt)
                     ?? throw new Exception("Invalid zoho_token.json");

        if (string.IsNullOrWhiteSpace(stored.refresh_token))
            throw new Exception("Refresh token missing.");

        return await RefreshToken(stored.refresh_token);
    }

    private async Task<ZohoToken> RefreshToken(string refreshToken)
    {
        using var client = new HttpClient();
        var response = await client.PostAsync(
            "https://accounts.zoho.eu/oauth/v2/token",
            new FormUrlEncodedContent(new Dictionary<string, string>
            {
                ["refresh_token"] = refreshToken,
                ["client_id"] = clientId,
                ["client_secret"] = clientSecret,
                ["grant_type"] = "refresh_token"
            }));

        var body = await response.Content.ReadAsStringAsync();

        if (!response.IsSuccessStatusCode)
            throw new Exception($"Zoho refresh failed ({response.StatusCode}): {body}");

        var nt = JsonSerializer.Deserialize<ZohoToken>(body)
                 ?? throw new Exception("Invalid token JSON");

        nt.refresh_token = refreshToken;

        await File.WriteAllTextAsync(_tokenFile, JsonSerializer.Serialize(nt, new JsonSerializerOptions { WriteIndented = true }));

        return nt;
    }
}
