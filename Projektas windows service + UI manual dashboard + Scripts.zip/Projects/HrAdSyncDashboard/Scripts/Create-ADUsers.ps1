﻿param(
    [string]$JsonFile = "C:\Projects\HrAdSyncDashboard\bin\Debug\net8.0\Data\LatestZoho.json"
)

# === Graph API Mail Setup ===
$tenantId     = 'aa563783-32f0-4b93-8097-311a572ac63e'
$clientId     = '4db7c4f4-5a70-4d9b-afde-ebe3bcf3f722'
$clientSecret = 'iIw8Q~QRlbG9tMDvcB-Rde2FMqSr8qXZE3T.Gcxe'
$fromAddress  = 'automation@eckamaster.onmicrosoft.com'
$toAddress    = 'automation@eckamaster.onmicrosoft.com'

function Send-GraphMailAlert($subject, $content) {
    $tokenBody = @{
        client_id     = $clientId
        scope         = "https://graph.microsoft.com/.default"
        client_secret = $clientSecret
        grant_type    = "client_credentials"
    }

    try {
        $tokenResponse = Invoke-RestMethod -Method Post -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" -Body $tokenBody
        $accessToken = $tokenResponse.access_token

        $emailBody = @{
            message = @{
                subject = $subject
                body = @{ contentType = "Text"; content = $content }
                toRecipients = @(@{ emailAddress = @{ address = $toAddress } })
            }
            saveToSentItems = $false
        } | ConvertTo-Json -Depth 5

        Invoke-RestMethod -Method Post -Uri "https://graph.microsoft.com/v1.0/users/$fromAddress/sendMail" `
            -Headers @{ Authorization = "Bearer $accessToken" } `
            -Body $emailBody -ContentType "application/json"

        Write-Output "Alert sent: $subject"
    } catch {
        Write-Warning "Failed to send alert: $($_.Exception.Message)"
    }
}

if (-not (Test-Path $JsonFile)) {
    Write-Error "JSON file not found: $JsonFile"
    exit 1
}

$records = Get-Content $JsonFile -Raw | ConvertFrom-Json
Write-Output "Loaded JSON — found $($records.Count) record(s)."

$seenSams = @()
$changeLog = @()

$roleGroupMap = @{
    "Admin" = "Admins"; "Helpdesk" = "Helpdesk"; "Network" = "NetworkTeam"
    "Server" = "ServerTeam"; "Team member" = "Users"; "Assistant Manager" = "Helpdesk"
}
$deptGroupMap = @{
    "IT" = "ITTeam"; "Management" = "ManagementGroup"; "Marketing" = "MarketingGroup"; "HR" = "HRGroup"
}

function Get-UniqueSam {
    param ($first, $last)
    $first = $first.ToLower(); $last = $last.ToLower()
    $patterns = @("$($first[0])$last", "$($first[0]).$last", "$($first.Substring(0,2)).$last")
    foreach ($base in $patterns) {
        if (-not (Get-ADUser -Filter "SamAccountName -eq '$base'" -ErrorAction SilentlyContinue)) {
            return $base
        }
    }
    throw "Too many conflicts for $first $last"
}

foreach ($rec in $records) {
    $first, $last, $email, $status, $role, $dept, $employeeId =
        $rec.FirstName, $rec.LastName, $rec.Email, $rec.Status, $rec.ZohoRole, $rec.Department, $rec.EmployeeID

    if (-not $first -or -not $last -or -not $email -or -not $employeeId) {
        Write-Warning "Skipping incomplete record."
        continue
    }

    $existing = Get-ADUser -Filter "EmployeeID -eq '$employeeId'" -Properties SamAccountName, GivenName, Surname,
        EmailAddress, UserPrincipalName, Enabled, MemberOf, ProxyAddresses, Name, Department, Title -ErrorAction SilentlyContinue

    $oldSurname = $existing.Surname

    if ($existing) {
        $sam = $existing.SamAccountName
        $seenSams += $sam
        Write-Output "Updating existing user with EmployeeID $employeeId ($sam)"

        $changes = @()
        $expectedUpn = "$sam@ecka.local"

        if ($existing.GivenName -ne $first) {
            $changes += @{ Field = "GivenName"; Old = $existing.GivenName; New = $first }
            Set-ADUser -Identity $existing -GivenName $first
        }

        # — EMAIL + PROXY ADDRESS HANDLING — only when surname really changed —
        if ($oldSurname -ne $last) {
            # 1) build unique new SMTP address
            $newMail = ("{0}.{1}" -f $first.Substring(0,1).ToLower(), $last.ToLower()) + "@eckamaster.onmicrosoft.com"
            $i = 97  # ASCII value for 'a'
            while (Get-ADUser -Filter "EmailAddress -eq '$newMail'" -ErrorAction SilentlyContinue) {
                $newMail = ("{0}{1}.{2}" -f $first.Substring(0,1).ToLower(), [char]$i, $last.ToLower()) + "@eckamaster.onmicrosoft.com"
                $i++ 
            }

            # 2) snapshot old proxies
            $oldProxies = @($existing.ProxyAddresses)
            $oldPrimary = ($oldProxies | Where-Object { $_ -match '^SMTP:' }) -replace '^SMTP:',''

            # 3) assemble new list
            $upn = $existing.UserPrincipalName
            $newProxies = @(
                "smtp:$sam@ecka.local"
                "SMTP:$newMail"

            )
            Set-ADObject -Identity $existing.DistinguishedName -Replace @{ proxyAddresses = $newProxies }
            Set-ADUser -Identity $existing -EmailAddress $newMail

            # 5) log the change
            $changes += [PSCustomObject]@{
                Field = "EmailAddress"
                Old   = $existing.EmailAddress
                New   = $newMail
            }
            $changes += [PSCustomObject]@{
                Field = "proxyAddresses"
                Old   = ($oldProxies -join ', ')
                New   = ($newProxies -join ', ')
            }
        }

        # now update surname on the account
        if ($existing.Surname -ne $last) {
            Set-ADUser -Identity $existing -Surname $last
            $changes += @{ Field="Surname"; Old=$oldSurname; New=$last }
        }

        $displayName = "$first $last"
        $oldDisplayName = $existing.DisplayName
        if (
            -not [string]::IsNullOrWhiteSpace($displayName) -and
            ($oldDisplayName -ne $displayName) -and
            -not ([string]::IsNullOrWhiteSpace($oldDisplayName))
        ) {
            try {
                Set-ADUser -Identity $existing -DisplayName $displayName
                $changes += @{
                    Field = "DisplayName"
                    Old   = $oldDisplayName
                    New   = $displayName
                }
            } catch {
                Write-Warning "Failed to update display name: $($_.Exception.Message)"
            }
        }

        $group = if ($roleGroupMap.ContainsKey($role)) { $roleGroupMap[$role] }
            elseif ($deptGroupMap.ContainsKey($dept)) { $deptGroupMap[$dept] } else { "Guests" }

        $existingGroups = $existing.MemberOf | ForEach-Object { (Get-ADObject $_).Name }
        if ($existingGroups -notcontains $group) {
            Add-ADGroupMember -Identity $group -Members $existing
            $changes += @{
                Field = "Group"
                Old   = ($existingGroups -join ', ')
                New   = $group
            }
        }

        if ($existing.Department -ne $dept) {
            Set-ADUser -Identity $existing -Department $dept
            $changes += @{
                Field = "Department"
                Old   = $existing.Department
                New   = $dept
            }
        }

        if ($existing.Title -ne $role) {
            Set-ADUser -Identity $existing -Title $role
            $changes += @{
                Field = "Role"
                Old   = $existing.Title
                New   = $role
            }
        }

        if ($status -ne "Active") {
            if ($existing.Enabled) {
                Disable-ADAccount -Identity $existing
                $changes += @{ Field = "Status"; Old = "Enabled"; New = "Disabled" }
            }
            $existing.MemberOf | ForEach-Object {
                Remove-ADGroupMember -Identity $_ -Members $existing -Confirm:$false
            }
            Add-ADGroupMember -Identity "Disabled-Users" -Members $existing
        } elseif (-not $existing.Enabled) {
            Enable-ADAccount -Identity $existing
            $changes += @{ Field = "Status"; Old = "Disabled"; New = "Enabled" }
        }

        if ($changes.Count -gt 0) {
            $changeLog += [PSCustomObject]@{
                Sam     = $sam
                Name    = "$first $last"
                Changes = $changes
            }
        }

        continue
    }

    # === New User Creation ===
    $sam = Get-UniqueSam $first $last
    $seenSams += $sam
    $newUPN = ("{0}.{1}" -f $first.ToLower(), $last.ToLower()) + "@ecka.local"
    $i = 1
    while (Get-ADUser -Filter "UserPrincipalName -eq '$newUPN'" -ErrorAction SilentlyContinue) {
        $newUPN = ("{0}.{1}{2}" -f $first.ToLower(), $last.ToLower(), $i) + "@ecka.local"
        $i++
    }
    $mail = ("{0}.{1}" -f $first.Substring(0,1).ToLower(), $last.ToLower()) + "@eckamaster.onmicrosoft.com"
    $i = 97  # ASCII value for 'a'
    while (Get-ADUser -Filter "EmailAddress -eq '$mail'" -ErrorAction SilentlyContinue) {
        $mail = ("{0}{1}.{2}" -f $first.Substring(0,1).ToLower(), [char]$i, $last.ToLower()) + "@eckamaster.onmicrosoft.com"
        $i++
    }
    $group = if ($roleGroupMap.ContainsKey($role)) { $roleGroupMap[$role] }
        elseif ($deptGroupMap.ContainsKey($dept)) { $deptGroupMap[$dept] } else { "Guests" }

    Add-Type -AssemblyName System.Web
    $password = [System.Web.Security.Membership]::GeneratePassword(12, 2)
    $securePassword = ConvertTo-SecureString -String $password -AsPlainText -Force

    $displayName = "$first $last"
    $existingCN = Get-ADUser -Filter "Name -eq '$displayName'" -SearchBase "OU=Users,OU=IT,DC=ecka,DC=local" -ErrorAction SilentlyContinue
    if ($existingCN) { $displayName = "$displayName ($sam)" }

    try {
        New-ADUser `
            -Name $displayName `
            -GivenName $first `
            -Surname $last `
            -SamAccountName $sam `
            -UserPrincipalName $newUPN `
            -EmailAddress $mail `
            -Department $dept `
            -Title $role `
            -EmployeeID $employeeId `
            -Path "OU=Users,OU=IT,DC=ecka,DC=local" `
            -AccountPassword $securePassword `
            -Enabled $true `
            -ChangePasswordAtLogon $true `
            -PasswordNeverExpires $false

        Add-ADGroupMember -Identity $group -Members $sam
        Write-Output "Created user: $sam added to $group"
        $changeLog += [PSCustomObject]@{
            Sam     = $sam
            Name    = "$first $last"
            Changes = @(
                @{ Field = "NewUser"; Old = "N/A"; New = $sam },
                @{ Field = "Group"; Old = "N/A"; New = $group },
                @{ Field = "Department"; Old = "N/A"; New = $dept },
                @{ Field = "Role"; Old = "N/A"; New = $role },
                @{ Field = "EmailAddress"; Old = "N/A"; New = $mail }
            )
        }
    } catch {
        Write-Warning "Failed to create user ${sam}: $($_.Exception.Message)"
    }
}

Write-Output "\n== Sweep Phase =="
$maps = $roleGroupMap.Values + $deptGroupMap.Values + "Guests"
$all = Get-ADUser -SearchBase "OU=Users,OU=IT,DC=ecka,DC=local" -Filter * -Properties Enabled,MemberOf

foreach ($u in $all) {
    if ($seenSams -notcontains $u.SamAccountName) {
        Write-Output "Orphaned: $($u.SamAccountName)"
        if ($u.Enabled) { Disable-ADAccount -Identity $u }
        $u.MemberOf | ForEach-Object {
            $gName = (Get-ADObject $_).Name
            if ($maps -contains $gName) {
                Remove-ADGroupMember -Identity $_ -Members $u -Confirm:$false
            }
        }
        Add-ADGroupMember -Identity "Disabled-Users" -Members $u
        Write-Output "Moved to Disabled-Users"
    }
}

if ($changeLog.Count -gt 0) {
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm'
    $body = "AD Sync Change Summary — $timestamp`n`n"
    foreach ($entry in $changeLog) {
        $body += "- $($entry.Name) ($($entry.Sam)):`n"
        foreach ($c in $entry.Changes) {
            $body += "    $($c.Field): '$($c.Old)' ---> '$($c.New)'`n"
        }
        $body += "`n"
    }
    Write-Output $body
    Send-GraphMailAlert "AD Sync Summary Report" $body
}