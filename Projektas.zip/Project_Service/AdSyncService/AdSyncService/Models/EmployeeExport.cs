﻿namespace AdSyncService.Models;

public class EmployeeExport
{
    public string ID { get; set; } = "";
    public string UserStatus { get; set; } = "new";
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public string FullName { get; set; } = "";
    public string Email { get; set; } = "";
    public string EmployeeID { get; set; } = "";
    public string PhoneNumber { get; set; } = "";
    public string IPAddress { get; set; } = "";
    public string Status { get; set; } = "Active";
    public string StartDate { get; set; } = "";
    public string LeaveDate { get; set; } = "";
    public string VacationStatus { get; set; } = "0";
    public string OriginCountry { get; set; } = "";
    public string TravelCountry { get; set; } = "";
    public string TravelStartDate { get; set; } = "";
    public string TravelEndDate { get; set; } = "";
    public string Department { get; set; } = "";
    public string ZohoRole { get; set; } = "";
}
