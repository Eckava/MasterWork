﻿using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Timers;

namespace AdSyncService.Services
{
    public class ScriptStatusService
    {
        // holds latest ScriptInfo
        private readonly ConcurrentDictionary<string, ScriptInfo> _statuses
            = new();

        // holds the timers so we can Start/Stop them
        private readonly ConcurrentDictionary<string, Timer> _timers
            = new();

        public IEnumerable<ScriptInfo> GetAll()
            => _statuses.Values.OrderBy(s => s.Name).ToList();

        public bool TryGet(string name, out ScriptInfo? info)
            => _statuses.TryGetValue(name, out info!);

        public void Update(ScriptInfo info)
        {
            // preserve existing IsEnabled if already known
            if (_statuses.TryGetValue(info.Name, out var old))
                info.IsEnabled = old.IsEnabled;
            else
                info.IsEnabled = true;

            _statuses[info.Name] = info;
        }

        public void RegisterTimer(string name, Timer t)
        {
            _timers[name] = t;

            // ensure we have a status entry so Dashboard sees it
            _statuses.AddOrUpdate(name,
                key => new ScriptInfo { Name = key, IsEnabled = true },
                (_, old) =>
                {
                    old.IsEnabled = true;
                    return old;
                });
        }

        public bool Start(string name)
        {
            if (_timers.TryGetValue(name, out var t))
            {
                t.Start();
                if (_statuses.TryGetValue(name, out var info))
                    info.IsEnabled = true;
                return true;
            }
            return false;
        }

        public bool Stop(string name)
        {
            if (_timers.TryGetValue(name, out var t))
            {
                t.Stop();
                if (_statuses.TryGetValue(name, out var info))
                    info.IsEnabled = false;
                return true;
            }
            return false;
        }
    }
}
