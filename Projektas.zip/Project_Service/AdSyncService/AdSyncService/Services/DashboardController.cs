﻿using System;
using System.IO;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using AdSyncService.Services;

[ApiController]
[Route("api/[controller]")]
public class DashboardController : ControllerBase
{
    private readonly ScriptStatusService _svc;
    private readonly ZohoService _zoho;
    private readonly string _dataFolder;
    private readonly string _zohoJsonPath;

    public DashboardController(ScriptStatusService svc, ZohoService zoho)
    {
        _svc = svc;
        _zoho = zoho;
        _dataFolder = Path.Combine(AppContext.BaseDirectory, "Data");
        _zohoJsonPath = Path.Combine(_dataFolder, "LatestZoho.json");
    }

    [HttpGet("status")]
    public IActionResult GetAll()
    {
        var scriptStatuses = _svc.GetAll();

        var zohoStatus = new
        {
            LastSync = _zoho.LastSyncTime.HasValue
                        ? _zoho.LastSyncTime.Value.ToString("G")
                        : "Never",
            LastStatus = _zoho.LastStatus ?? "Unknown"
        };

        Console.WriteLine($"[DashboardController] LastSyncTime={_zoho.LastSyncTime} | LastStatus={_zoho.LastStatus}");


        return Ok(new
        {
            Scripts = scriptStatuses,
            Zoho = zohoStatus
        });
    }

    [HttpGet("log/{name}")]
    public IActionResult GetLog(string name)
    {
        if (!Directory.Exists(_dataFolder))
            return NotFound(new { message = "No log directory" });

        var files = Directory.GetFiles(_dataFolder, $"{name}_*.log")
                             .OrderByDescending(f => f)
                             .ToArray();

        if (files.Length == 0)
            return NotFound(new { message = "No log file found" });

        var file = files[0];
        var content = System.IO.File.ReadAllText(file);

        return Content(content, "text/plain");
    }

    // NEW ENDPOINT: Get Zoho Last Sync based on file timestamp
    [HttpGet("zoho-last-sync")]
    public IActionResult GetZohoLastSync()
    {
        if (!System.IO.File.Exists(_zohoJsonPath))
        {
            return NotFound(new { message = "LatestZoho.json not found." });
        }

        var lastModified = System.IO.File.GetLastWriteTime(_zohoJsonPath);
        return Ok(new
        {
            LastSyncTime = lastModified.ToString("yyyy-MM-dd HH:mm:ss")
        });
    }
}
