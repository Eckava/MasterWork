﻿<#
.SYNOPSIS
    Non-interactive Azure AD sign-in audit & reset enforcer using REST only.

.DESCRIPTION
    1. App-only authenticate to Microsoft Graph.
    2. Load HR data from a local JSON file.
    3. Fetch sign-in logs for the last 24 hours via Graph REST.
    4. Compare against HR origin/travel data.
    5. Force password reset for suspicious logins (with a temporary password).
#>

# --- CONFIGURATION ---
$tenantId     = 'aa563783-32f0-4b93-8097-311a572ac63e'
$clientId     = 'eee16756-7a95-4fd8-8051-c3b64770a792'
$clientSecret = 'JX08Q~KFgxY2IZ1rLNGgWgso1K3BA2kA1MKYSbx8'
$hrJsonPath   = 'C:\Projects\HrAdSyncDashboard\bin\Debug\net8.0\Data\LatestZoho.json'

# --- STEP 1: Acquire Graph token inline ---
Write-Host "Acquiring Graph token…"
try {
    $tokenResponse = Invoke-RestMethod -Method Post `
        -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" `
        -Body @{
            client_id     = $clientId
            scope         = 'https://graph.microsoft.com/.default'
            client_secret = $clientSecret
            grant_type    = 'client_credentials'
        } -ErrorAction Stop

    $token = $tokenResponse.access_token
    $hdr = @{ Authorization = "Bearer $token" }

} catch {
    Write-Error "Failed to get token: $($_.Exception.Message)"
    exit 1
}

# --- Graph Mail Sender Function ---
function Send-GraphMailAlert($subject, $content) {
    $fromAddress = 'automation@eckamaster.onmicrosoft.com'
    $toAddress   = 'automation@eckamaster.onmicrosoft.com'

    $emailBody = @{
        message = @{
            subject = $subject
            body = @{ contentType = "Text"; content = $content }
            toRecipients = @(@{ emailAddress = @{ address = $toAddress } })
        }
        saveToSentItems = $false
    } | ConvertTo-Json -Depth 5

    try {
        Invoke-RestMethod -Method Post `
            -Uri "https://graph.microsoft.com/v1.0/users/$fromAddress/sendMail" `
            -Headers @{ Authorization = "Bearer $token" } `
            -Body $emailBody -ContentType "application/json"

        Write-Host "✅ Alert sent: $subject"
    } catch {
        Write-Warning "❌ Failed to send alert: $($_.Exception.Message)"
    }
}

# --- STEP 2: Load HR JSON ---
if (-not (Test-Path $hrJsonPath)) {
    Write-Error "HR JSON not found at $hrJsonPath"
    exit 1
}
$hrData = Get-Content $hrJsonPath -Raw | ConvertFrom-Json

# Build lookup: index by Zoho email…
$hrLookup = @{}
foreach ($r in $hrData) {
    if ($r.Email) { $hrLookup[$r.Email.ToLower()] = $r }
}
# …and also index each record under AD UPN aliases
foreach ($r in $hrData) {
    $localPart = $r.Email.ToLower().Split('@')[0]
    foreach ($alias in @("$localPart@eckamaster.onmicrosoft.com","$localPart@ecka.local")) {
        if (-not $hrLookup.ContainsKey($alias)) {
            $hrLookup[$alias] = $r
        }
    }
}
Write-Host "Expanded lookup to $($hrLookup.Count) entries (including UPN aliases)."

# --- STEP 3: Country map (abbreviated) ---
$countryMap = @{
"AF"="Afghanistan"; "AX"="Åland Islands"; "AL"="Albania"; "DZ"="Algeria"; "AS"="American Samoa"; 
    "AD"="Andorra"; "AO"="Angola"; "AQ"="Antarctica"; "AG"="Antigua and Barbuda"; "AR"="Argentina";
    "AM"="Armenia"; "AW"="Aruba"; "AU"="Australia"; "AT"="Austria"; "AZ"="Azerbaijan";
    "BS"="Bahamas"; "BH"="Bahrain"; "BD"="Bangladesh"; "BB"="Barbados"; "BY"="Belarus";
    "BE"="Belgium"; "BZ"="Belize"; "BJ"="Benin"; "BM"="Bermuda"; "BT"="Bhutan";
    "BO"="Bolivia"; "BQ"="Bonaire"; "BA"="Bosnia and Herzegovina"; "BW"="Botswana"; "BV"="Bouvet Island";
    "BR"="Brazil"; "IO"="British Indian Ocean Territory"; "VG"="British Virgin Islands"; "BN"="Brunei"; "BG"="Bulgaria";
    "BF"="Burkina Faso"; "BI"="Burundi"; "CV"="Cabo Verde"; "KH"="Cambodia"; "CM"="Cameroon";
    "CA"="Canada"; "KY"="Cayman Islands"; "CF"="Central African Republic"; "TD"="Chad"; "CZ"="Czechia";
    "CL"="Chile"; "CN"="China"; "CX"="Christmas Island"; "CC"="Cocos (Keeling) Islands"; "CO"="Colombia";
    "KM"="Comoros"; "CG"="Congo"; "CD"="Congo (DRC)"; "CK"="Cook Islands"; "CR"="Costa Rica";
    "CI"="Côte d'Ivoire"; "HR"="Croatia"; "CU"="Cuba"; "CW"="Curaçao"; "CY"="Cyprus";
    "DK"="Denmark"; "DJ"="Djibouti"; "DM"="Dominica"; "DO"="Dominican Republic"; "EC"="Ecuador";
    "EG"="Egypt"; "SV"="El Salvador"; "GQ"="Equatorial Guinea"; "ER"="Eritrea"; "EE"="Estonia";
    "SZ"="eSwatini"; "ET"="Ethiopia"; "FO"="Faroe Islands"; "FJ"="Fiji"; "FI"="Finland";
    "FR"="France"; "GF"="French Guiana"; "PF"="French Polynesia"; "TF"="French Southern Territories"; "GA"="Gabon";
    "GM"="Gambia"; "GE"="Georgia"; "DE"="Germany"; "GH"="Ghana"; "GI"="Gibraltar";
    "GR"="Greece"; "GL"="Greenland"; "GD"="Grenada"; "GP"="Guadeloupe"; "GU"="Guam";
    "GT"="Guatemala"; "GG"="Guernsey"; "GN"="Guinea"; "GW"="Guinea-Bissau"; "GY"="Guyana";
    "HT"="Haiti"; "HM"="Heard Island and McDonald Islands"; "HN"="Honduras"; "HK"="Hong Kong SAR"; "HU"="Hungary";
    "IS"="Iceland"; "IN"="India"; "ID"="Indonesia"; "IR"="Iran"; "IQ"="Iraq";
    "IE"="Ireland"; "IM"="Isle of Man"; "IL"="Israel"; "IT"="Italy"; "JM"="Jamaica";
    "JP"="Japan"; "JE"="Jersey"; "JO"="Jordan"; "KZ"="Kazakhstan"; "KE"="Kenya";
    "KI"="Kiribati"; "KR"="Korea (South)"; "KW"="Kuwait"; "KG"="Kyrgyzstan"; "LA"="Laos";
    "LV"="Latvia"; "LB"="Lebanon"; "LS"="Lesotho"; "LR"="Liberia"; "LY"="Libya";
    "LI"="Liechtenstein"; "LT"="Lithuania"; "LU"="Luxembourg"; "MO"="Macao SAR"; "MG"="Madagascar";
    "MW"="Malawi"; "MY"="Malaysia"; "MV"="Maldives"; "ML"="Mali"; "MT"="Malta";
    "MH"="Marshall Islands"; "MQ"="Martinique"; "MR"="Mauritania"; "MU"="Mauritius"; "YT"="Mayotte";
    "MX"="Mexico"; "FM"="Micronesia"; "MD"="Moldova"; "MC"="Monaco"; "MN"="Mongolia";
    "ME"="Montenegro"; "MS"="Montserrat"; "MA"="Morocco"; "MZ"="Mozambique"; "MM"="Myanmar";
    "NA"="Namibia"; "NR"="Nauru"; "NP"="Nepal"; "NL"="Netherlands"; "NC"="New Caledonia";
    "NZ"="New Zealand"; "NI"="Nicaragua"; "NE"="Niger"; "NG"="Nigeria"; "NU"="Niue";
    "NF"="Norfolk Island"; "KP"="North Korea"; "MP"="Northern Mariana Islands"; "MK"="North Macedonia"; "NO"="Norway";
    "OM"="Oman"; "PK"="Pakistan"; "PW"="Palau"; "PS"="Palestinian Authority"; "PA"="Panama";
    "PG"="Papua New Guinea"; "PY"="Paraguay"; "PE"="Peru"; "PH"="Philippines"; "PN"="Pitcairn Islands";
    "PL"="Poland"; "PT"="Portugal"; "PR"="Puerto Rico"; "QA"="Qatar"; "RE"="Réunion";
    "RO"="Romania"; "RU"="Russia"; "RW"="Rwanda"; "BL"="Saint Barthélemy"; "KN"="Saint Kitts and Nevis";
    "LC"="Saint Lucia"; "MF"="Saint Martin"; "PM"="Saint Pierre and Miquelon"; "VC"="Saint Vincent and the Grenadines"; 
    "WS"="Samoa"; "SM"="San Marino"; "ST"="São Tomé and Príncipe"; "SA"="Saudi Arabia"; "SN"="Senegal";
    "RS"="Serbia"; "SC"="Seychelles"; "SL"="Sierra Leone"; "SG"="Singapore"; "SX"="Sint Maarten";
    "SK"="Slovakia"; "SI"="Slovenia"; "SB"="Solomon Islands"; "SO"="Somalia"; "ZA"="South Africa";
    "GS"="South Georgia and South Sandwich Islands"; "SS"="South Sudan"; "ES"="Spain"; "LK"="Sri Lanka"; "SH"="St Helena, Ascension, Tristan da Cunha";
    "SD"="Sudan"; "SR"="Suriname"; "SJ"="Svalbard"; "SE"="Sweden"; "CH"="Switzerland";
    "SY"="Syria"; "TW"="Taiwan"; "TJ"="Tajikistan"; "TZ"="Tanzania"; "TH"="Thailand";
    "TL"="Timor-Leste"; "TG"="Togo"; "TK"="Tokelau"; "TO"="Tonga"; "TT"="Trinidad and Tobago";
    "TN"="Tunisia"; "TR"="Türkiye"; "TM"="Turkmenistan"; "TC"="Turks and Caicos Islands"; "TV"="Tuvalu";
    "UG"="Uganda"; "UA"="Ukraine"; "AE"="United Arab Emirates"; "GB"="United Kingdom"; "US"="United States";
    "UY"="Uruguay"; "UM"="U.S. Outlying Islands"; "VI"="U.S. Virgin Islands"; "UZ"="Uzbekistan"; "VU"="Vanuatu";
    "VA"="Vatican City"; "VE"="Venezuela"; "VN"="Vietnam"; "WF"="Wallis and Futuna"; "YE"="Yemen";
    "ZM"="Zambia"; "ZW"="Zimbabwe"
}

# --- STEP 4: Fetch sign‑ins last 24h via REST ---
$sinceUtc = (Get-Date).AddDays(-1).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
$filter   = "createdDateTime ge $sinceUtc"
$uri      = "https://graph.microsoft.com/v1.0/auditLogs/signIns?`$filter=$([uri]::EscapeDataString($filter))&`$top=999"

Write-Host "Querying sign‑ins since $sinceUtc…"
try {
    $resp    = Invoke-RestMethod -Headers $hdr -Uri $uri -ErrorAction Stop
    $signIns = $resp.value
    Write-Host "Retrieved $($signIns.Count) events."
}
catch {
    Write-Error "Failed to fetch sign‑ins: $($_.Exception.Message)"
    exit 1
}

# --- STEP 5: Analyze & enforce ---
foreach ($log in $signIns) {
    $upnRaw      = $log.userPrincipalName
    if (-not $upnRaw) { continue }
    $upn         = $upnRaw.ToLower()
    $loginTime   = [datetime]$log.createdDateTime
    $countryCode = ($log.location.countryOrRegion.Split(',')[-1]).Trim()

    # Map code → full country
    $loginCountry = if ($countryMap.ContainsKey($countryCode)) { $countryMap[$countryCode] } else { $countryCode }

    if (-not $hrLookup.ContainsKey($upn)) {
        Write-Host "No HR entry for $upn, skipping."
        continue
    }

    $r       = $hrLookup[$upn]
    $orig    = $r.OriginCountry
    $travel  = $r.TravelCountry
    $vacFlag = [int]$r.VacationStatus

    # parse travel window
    $start = $null; $end = $null
    if ($r.TravelStartDate) { [datetime]::TryParse($r.TravelStartDate,[ref]$start) | Out-Null }
    if ($r.TravelEndDate)   { [datetime]::TryParse($r.TravelEndDate,  [ref]$end)   | Out-Null }
    $isTraveling = $false
    if ($start -and $end) {
        $isTraveling = ($loginTime -ge $start -and $loginTime -le $end) -and ($loginCountry -eq $travel)
    }

   $msg = "Suspicious login detected:`nUser: $upn`nTime: $loginTime`nLocation: $loginCountry`nHR Origin: $orig`n"
Write-Warning $msg
Send-GraphMailAlert " Suspicious Login Alert — $upn" $msg

       
    }


